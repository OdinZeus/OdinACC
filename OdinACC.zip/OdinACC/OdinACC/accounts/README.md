Accounts module contains masters and transactions to manage a traditional
double entry accounting system.

Accounting heads are called "Accounts" and they can be groups in a tree like
"Chart of Accounts"

Entries are:

- Journal Entries
- Sales Invoice (Itemised)
- Purchase Invoice (Itemised)

All accounting entries are stored in the `General Ledger`